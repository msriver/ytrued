var email, pw, name, phone;

verifyEmail = function () {
    // 이메일 검증 스크립트 작성
    var emailVal = $("#email").val();

    var regExp = /^[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*.[a-zA-Z]{2,3}$/i;

    if (emailVal.match(regExp) != null) {
        $("#email").parent().removeClass("wrong-input");
        $("#email-wrong-text").removeClass("wrong-text-show");
        $("#emailv").addClass("checkicon-show");
        email = true;
    }
    else {
        $("#email").parent().addClass("wrong-input");
        $("#email-wrong-text").addClass("wrong-text-show");
        $("#emailv").removeClass("checkicon-show");
        email = false;
    }
}

verifyLoginId = function() {
    if(document.frm.email.value.length==0){
        $("#email").parent().addClass("wrong-input");
        $("#email-wrong-text").addClass("wrong-text-show");
        $("#emailv").removeClass("checkicon-show");
        email = false;
    } else {
        $("#email").parent().removeClass("wrong-input");
        $("#email-wrong-text").removeClass("wrong-text-show");
        $("#emailv").addClass("checkicon-show");
        email = true;
    }
}

verifyLoginPw = function() {
    if(document.frm.email.value.length==0){
        $("#pw").parent().addClass("wrong-input");
        $("#pw-wrong-text").addClass("wrong-text-show");
        $("#pwv").removeClass("checkicon-show");
        pw=false;
    } else {
        $("#pw").parent().removeClass("wrong-input");
        $("#pw-wrong-text").removeClass("wrong-text-show");
        $("#pwv").addClass("checkicon-show");
        pw=true;
    }
}

var pwVerifyOk = false; // 비밀번호 확인용
verifyPW = function () {
    // 비밀번호 검증 스크립트 작성
    var pwVal = $("#pw").val();

    var regExp = /^.*(?=^.{6,15}$)(?=.*\d)(?=.*[a-zA-Z])(?=.*[!@#$%^&+=]).*$/;

    if (pwVal.match(regExp) != null) {
        $("#pw").parent().removeClass("wrong-input");
        $("#pw-wrong-text").removeClass("wrong-text-show");
        $("#pwv").addClass("checkicon-show");
        pwVerifyOk=true;
    }
    else {
        $("#pw").parent().addClass("wrong-input");
        $("#pw-wrong-text").addClass("wrong-text-show");
        $("#pwv").removeClass("checkicon-show");
        pwVerifyOk=false;
    }
}

verifyPWcheck = function () {
    // 비밀번호 확인 검증 스크립트 작성
    var pwVal = $("#pw").val();
    var pwCheck = $("#pwcheck").val();

    if (pwVerifyOk&&pwVal == pwCheck) {
        $("#pwcheck").parent().removeClass("wrong-input");
        $("#pwc-wrong-text").removeClass("wrong-text-show");
        $("#pwcv").addClass("checkicon-show");
        pw = true;
    }
    else {
        $("#pwcheck").parent().addClass("wrong-input");
        $("#pwc-wrong-text").addClass("wrong-text-show");
        $("#pwcv").removeClass("checkicon-show");
        pw = false;
    }
}

verifyName = function () {
    // 이름 빈칸 검증 스크립트 작성
    var nameVal = $("#name").val();
    var regExp = /^[가-힣a-zA-Z]+$/;
    if (nameVal.match(regExp) != null) {
        $("#name").parent().removeClass("wrong-input");
        $("#name-wrong-text").removeClass("wrong-text-show");
        $("#namev").addClass("checkicon-show");
        name = true;
    }
    else {
        $("#name").parent().addClass("wrong-input");
        $("#name-wrong-text").addClass("wrong-text-show");
        $("#namev").removeClass("checkicon-show");
        name = false;
    }
}

verifyPhone = function () {
    //  폰번 검증 스크립트 작성
    var namePhone = $("#phone").val();
    var regExp = "^01(?:0|1|[6-9])[.-]?(\\d{3}|\\d{4})[.-]?(\\d{4})$";
    if (namePhone.match(regExp) != null) {
        $("#phone").parent().removeClass("wrong-input");
        $("#phone-wrong-text").removeClass("wrong-text-show");
        $("#phonev").addClass("checkicon-show");
        phone = true;
    }
    else {
        $("#phone").parent().addClass("wrong-input");
        $("#phone-wrong-text").addClass("wrong-text-show");
        $("#phonev").removeClass("checkicon-show");
        phone = false;
    }
}

//버튼 누를시 전체 입력값 제대로 된지 검사하기
verifyAll = function() {
    verifyEmail();
    verifyName();
    verifyPW();
    verifyPWcheck();
    verifyPhone();
    if(!email||!pw||!pwVerifyOk||!name||!phone){
        return false;
    }
}

verifyLAll = function() {
	verifyLoginId();
	verifyLoginPw();
    if(!email||!pw){
        return false;
    }
}